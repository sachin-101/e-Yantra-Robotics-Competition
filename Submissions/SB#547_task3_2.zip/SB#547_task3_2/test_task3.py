###############################################################################
## Author: Team Supply Bot
## Edition: eYRC 2019-20
## Instructions: Do Not modify the basic skeletal structure of given APIs!!!
###############################################################################

######################
## Essential libraries
######################
import cv2
import numpy as np
import os
import math
import csv
import copy


############################################
## Build your algorithm in this function
## ip_image: is the array of the input image
## imshow helps you view that you have loaded
## the corresponding image
############################################

def getcolourmask(img,colour_low, colour_high):
    mask = cv2.inRange(img,colour_low,colour_high)
    return mask

def filter_img(mask):
    #filtering the mask
    kernel = np.ones((5,5),np.uint8)
    mask_opened = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    return mask_opened

def contour(mask,ip_image):
    cnt,hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[:2]
    area = []
    for i in range(len(cnt)):
        area.append(cv2.contourArea(cnt[i]))
    cnt_min = np.argmin(area)
    (x,y),rad = cv2.minEnclosingCircle(cnt[cnt_min])
    center = (int(x),int(y))
    cv2.circle(ip_image,center,int(rad),(255,0,0),2)
    return x,y,rad,ip_image

def angle(x0,y0,x1,y1,x2,y2):
    vx = x2-x1                  #distance from red dot to green dot
    vy = y2-y1
    vrx1 = x1-x0                 #distance from red dot to origin (radius)
    vry1 = y1-y0
    vrx2 = x2 - x0
    vry2 = y2 - y0
    #Calculating Angle A
    l = math.sqrt((vx*vx)+(vy*vy))       #using the formula (Cosine rule) CosA = (r1^2+r2^2-l^2)/(2*r1*r2) where A is the angle between the lines
    r1 = math.sqrt((vrx1*vrx1)+(vry1*vry1))
    r2 = math.sqrt((vrx2*vrx2)+(vry2*vry2))
    angle = math.acos(((r1*r1)+(r2*r2)-l*l)/(2*r1*r2))
    angle = (angle*180)/math.pi
    A = round(angle,2)
    return A

def process(ip_image):
    ###########################
    ## Your Code goes here
    ###########################
    #range of colors
    purple_low = np.array([100,100,20])
    purple_high = np.array([155,255,255])
    red_low = np.array([160,100,100])
    red_high = np.array([179,255,255])
    green_low = np.array([20,80,130])
    green_high = np.array([80,250,255])

    img_hsv = cv2.cvtColor(ip_image, cv2.COLOR_BGR2HSV)

    #extract outer purple circle
    purple_mask = getcolourmask(img_hsv,purple_low,purple_high)
    purple_mask = filter_img(purple_mask)
    kernel= (5,5)
    dilate_purple = cv2.dilate(purple_mask,kernel,iterations = 1)
    contours, hierarchy = cv2.findContours(dilate_purple, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[:2]
    x = np.zeros(ip_image.shape, dtype = np.uint8)
    cv2.drawContours(x, contours, -1, (255,255,255), -1)
    img_masked_bgr = np.bitwise_and(x,ip_image)
    img_masked = cv2.cvtColor(img_masked_bgr, cv2.COLOR_BGR2HSV)
    
    #red coin detection
    red_mask = getcolourmask(img_masked, red_low,red_high)
    red_mask = filter_img(red_mask)
    x1,y1,rad_red,ip_image = contour(red_mask,ip_image)
    
    #origin detection
    img_gray = cv2.cvtColor(img_masked_bgr, cv2.COLOR_BGR2GRAY)
    ret,mask_origin = cv2.threshold(img_gray,180,255,cv2.THRESH_BINARY)
    mask_origin = filter_img(mask_origin)
    x0,y0,rad_white,ip_image = contour(mask_origin,ip_image)
    
    #green coin detection
    green_mask = getcolourmask(img_masked, green_low, green_high)
    green_mask = filter_img(green_mask)
    x2,y2,rad_green,ip_image = contour(green_mask,ip_image)
        
    a = angle(x0,y0,x1,y1,x2,y2)
    angle_final = str(a)
    font = cv2.FONT_HERSHEY_SIMPLEX  #Printing the calculated angle on the image
    cv2.putText(ip_image,"Angle: "+angle_final,(10,30),font,0.5,(0,0,255),1)
    op_image = ip_image
    return op_image

####################################################################
## The main program which provides read in input of one image at a
## time to process function in which you will code your generalized
## output computing code
## Modify the image name as per instruction
####################################################################
def main():
    ################################################################
    ## variable declarations
    ################################################################
    i = 1
    ## reading in video 
    cap = cv2.VideoCapture(1) #if you have a webcam on your system, then change 0 to 1
    ## getting the frames per second value of input video
    fps = cap.get(cv2.CAP_PROP_FPS)
    ## setting the video counter to frame sequence
    cap.set(3, 640)
    cap.set(4, 480)
    ## reading in the frame
    ret, frame = cap.read()
    ## verifying frame has content
    print(frame.shape)
    while(ret):
        ret, frame = cap.read()
        ## display to see if the frame is correct
        cv2.imshow("window", frame)
        cv2.waitKey(int(1000/fps));
        ## calling the algorithm function
        op_image = process(frame)
        cv2.imwrite("SB#547_task3I.jpg",op_image)

############################################################################################
## main function
############################################################################################
if __name__ == '__main__':
    main()
