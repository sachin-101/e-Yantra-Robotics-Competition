'''
*Team Id: #547
*Author List: Sachin Kumar, Kirthika Srinivasan 
*Filename: deblurring.py
*Theme: Supply Bot 
*Functions: wiener_filter(img,kernel,S), calcPSF(filter_height, filter_width, length, theta),apply_kernel(img, kernel, S)
*           deblur(ip_image, len_psf, theta, beta, d, sigmaColor, sigmaSpace, orig_img)           
*Global Variables: NONE
'''

import cv2
import numpy as np
import os
import time
import math
import csv
import cv2.aruco as aruco
from aruco_utils import detect_aruco, calculate_Robot_State
import copy

'''
*Function Name: weiner_filter
*Input: img -> Input frame from the camera 
        kernel -> PSF filter 
        S -> power spectral density of the original image
*Output: returns deblurred_img -> image after performing wiener deconvolution 
*Logic: In the frequency domain, deblurred signal y(w) = x(w)*g(w) where g(w) is the wiener filter. This function converts the blurred image in
        the frequency domain and performs weiner deconvolution to retain x(w)
*Example Call: img_deblurred = wiener_filter(img, kernel, S)

'''
def wiener_filter(img, kernel, S):
    kernel /= np.sum(kernel) 
    f_img = np.fft.fft2(np.copy(img))
    kernel = np.fft.fft2(kernel, s = np.array(S.shape))
    x = (np.abs(kernel)**2)*S
    m,n = x.shape
    for i in range(m):
        for j in range(n):
            if int(x[i][j])==0:
                x[i][j] =1
    kernel = (np.conj(kernel)*S) / x
    f_img = f_img * kernel
    deblurred_img = np.abs(np.fft.ifft2(f_img))
    return deblurred_img

'''
*Function Name: calcPSF
*Input: filter_height -> no of rows in the filter matrix
       filter_width -> no of columns in the filter matrix
       length -> extent of length of deblurring 
       theta -> angle of the ellipse(perpendiculat to which deblurring occurs)
*Output: h -> deblurring kernel which will be deconvolved 
*Logic - to generate point spread function based on the given parameters of size, length of blurring and angle of the linear blurring
*Example Call - kernel = calcPSF(20,20,4,30) # deblurring at angle of 30 degrees using filter size(20,20)
'''
def calcPSF(filter_height, filter_width, length, theta):
	h = np.zeros((filter_height, filter_width))
	y, x = int(filter_height / 2), int(filter_width / 2)
	h = cv2.ellipse(h, (y, x), (0, int(length/2)), theta, 0, 360, 255, cv2.FILLED)    # Drawing ellipse
	sum_h = cv2.sumElems(h)[0]
	h = h #/ sum_h
	return h

'''
*Function Name: apply_kernel
*Input: img - input frame from camera 
*       kernel - Point spread function to be deconvolved
*       S - power spectral density of original image 
*Output: new_img -> deblurred image with all the B,G,R layers
*Logic - This function applies wiener_filter and performs wiener deconvolution for R,G,B layers separately
*Example Call - deblurred_img = apply_kernel(image,PSF,Power_Spectral_density)
'''
def apply_kernel(img, kernel, S):
	new_img = np.zeros(img.shape)
	new_img[...,0] = wiener_filter(img[...,0], kernel, S)
	new_img[...,1] = wiener_filter(img[...,1], kernel, S)
	new_img[...,2] = wiener_filter(img[...,2], kernel, S)
	return new_img

'''
*Function Name: deblur
*
*Input: ip_image -> input frame from camera
*       len_psf -> length of blurring 
*       theta -> angle along which blurring has occured
*       beta -> parameter for finding power spectral density
*       d -> diameter of pixel neighbourhood while bilateral filtering
*       sigmaColor -> parameter in color space,
*       sigmaSpace -> parameter in coordinate space
*       orig_img -> original frame without deblurring
*
*Output: output_img -> deblurred img after increasing brightness
*        h_kernel -> Point spread function
*        S -> Power spectral density of original image
*        filtered_img ->frame after deblurring
*        norm_img -> image after normalizing to 0-255 range
*Logic -> This function calculates Power spectral density of original image, then performs wiener deconvolution to each input frame. Post processing is done on 
*        deblurred frame using bilateral filter, which removes noise while preserving the edges.  
*Example call: deblur(frame, 4, 30, 8000, 4,30,30)
'''
def deblur(ip_image, len_psf, theta, beta, d, sigmaColor, sigmaSpace, orig_img):
    id_list = []

    # Calculate power spectral density
    S = (np.absolute(np.fft.fftshift(np.fft.fft2(orig_img[...,0])))**2)/beta
    
    # weiner kernel
    h_kernel = calcPSF(20, 20, len_psf, theta)
    filtered_img = apply_kernel(ip_image, h_kernel, S)

    # Restored filtered image
    norm_img = cv2.normalize(filtered_img, None, alpha=0, beta=255, 
                                norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    
    # # post processing to remove ringing
    norm_img = cv2.bilateralFilter(norm_img,d,sigmaColor,sigmaSpace)
    
    # # Increase contrast of filtered image
    alpha = 3   # contrast
    beta = 5   # brightness 
    output_img = cv2.convertScaleAbs(norm_img, alpha=alpha, beta=beta)
    # output_img = norm_img
    return output_img, h_kernel, S, filtered_img, norm_img

