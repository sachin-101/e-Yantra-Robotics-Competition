'''
*Team Id: #547
*Author List: Sachin Kumar, Kirthika Srinivasan 
*Filename: aruco_utils.py
*Theme: Supply Bot 
*Functions: angle_calculate(pt1,pt2,trigger), detect_aruco(img),mark_Aruco(img,aruco_list),
            get_aruco_center(aruco_dict_entry),calculate_Robot_State(img,aruco_list),mask_bot(highway)
*Global Variables: BOT_ARUCO = 25
'''
import cv2
import numpy as np
import cv2.aruco as aruco
import math 

BOT_ARUCO = 25

'''
*Function Name: angle_calculate
*Input: pt1 -> coordinates of point 1 as a tuple
        pt2 -> coordinates of point 2 as a tuple
*Output: angle -> slope of the line joining the 2 points in range (0,359)
*Logic : calculate slope using formula m = tan-1((y2- y1)/(x2 - x1))
*Example Call: angle = angle_calculate((50,100),(100,200))
'''
def angle_calculate(pt1,pt2, trigger = 0):  # function which returns angle between two points in the range of 0-359
    angle_list_1 = list(range(359,0,-1))
    #angle_list_1 = angle_list_1[90:] + angle_list_1[:90]
    angle_list_2 = list(range(359,0,-1))
    angle_list_2 = angle_list_2[-90:] + angle_list_2[:-90]
    x=pt2[0]-pt1[0] # unpacking tuple
    y=pt2[1]-pt1[1]
    angle=int(math.degrees(math.atan2(y,x))) #takes 2 points nad give angle with respect to horizontal axis in range(-180,180)
    if trigger == 0:
        angle = angle_list_2[angle]
    else:
        angle = angle_list_1[angle]
    return int(angle)

'''
*Function Name: detect_aruco
*Input: img -> input frame captured by camera
*Output: aruco_list -> dictionary containing aruco id as key and corner coordinates of the corresponding aruco
*Logic: Using cv2.aruco.detectMarkers, all arucos belonging to the 5x5_50 dictionary are detected in the frame.  
*Example Call: aruco_list = detect_aruco(img)
'''
def detect_aruco(img):  #returns the detected aruco list dictionary with id: corners
    aruco_list = {}
    dict_flag = cv2.aruco.DICT_7X7_250
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_5X5_50)   #creating aruco_dict with 5x5 bits with max 250 ids..so ids ranges from 0-249
    parameters = cv2.aruco.DetectorParameters_create()  #refer opencv page for clarification
    corners, ids, _ = cv2.aruco.detectMarkers(gray, aruco_dict, parameters = parameters)
    gray = cv2.aruco.drawDetectedMarkers(gray, corners,ids)
    if len(corners):    
        for k in range(len(corners)):
            temp_1 = corners[k]
            temp_1 = temp_1[0]
            temp_2 = ids[k]
            temp_2 = temp_2[0]
            aruco_list[temp_2] = temp_1
        return aruco_list


'''
*Function Name: mark_Aruco
*Input : img -> input frame captured by the camera
         aruco_list ->  dictionary containing aruco id as key and corner coordinates of the corresponding aruco
*Output: img -> image with the center marked and the aruco id displayed 
*Logic: Determine the center of the aruco by getting the average value of the x and y coordinates( as aruco is a square)
        Then using drawing functions the center is drawn and ID is displayed. 
*Example Call:  dict_entry = {25:(4,4),(4,9),(9,9),(9,4)}
                img = mark_Aruco(img,dict_entry)
'''
def mark_Aruco(img, aruco_list):    #function to mark the centre and display the id
    key_list = aruco_list.keys()
    font = cv2.FONT_HERSHEY_SIMPLEX
    for key in key_list:
        dict_entry = aruco_list[key]    #dict_entry is a numpy array with shape (4,2)
        centre = dict_entry[0] + dict_entry[1] + dict_entry[2] + dict_entry[3]#so being numpy array, addition is not list addition
        centre[:] = [int(x / 4) for x in centre]    #finding the centre
        orient_centre = centre + [0.0,5.0]
        centre = tuple(centre)  
        orient_centre = tuple((dict_entry[0]+dict_entry[1])/2)
        
        cv2.circle(img,centre,1,(0,0,255),8)
        cv2.circle(img,orient_centre,1,(0,0,255),8)
        cv2.line(img,centre,orient_centre,(255,0,0),4) #marking the centre of aruco
        cv2.putText(img, str(key), (int(centre[0] + 20), int(centre[1])), font, 1, (0,0,255), 2, cv2.LINE_AA) # displaying the idno
    return img

'''
*Function Name: get_aruco_center
*Input:     aruco_dict_entry -> one dictionary entry from the aruco_list containing all the coordinates of the detected arucos
*Output:    center -> center coordinates of the aruco as tuple
*Logic: As aruco is a square, the x and y coordinates are given by (x1+x2+x3+x4)/4 
*Example Call: dict_entry = {25:(4,4),(4,9),(9,9),(9,4)}
               center = mark_Aruco(img,dict_entry)
'''
def get_aruco_center(aruco_dict_entry):
    centre = aruco_dict_entry[0] + aruco_dict_entry[1] + aruco_dict_entry[2] + aruco_dict_entry[3]#so being numpy array, addition is not list addition
    centre[:] = [int(x / 4) for x in centre]    #finding the centre
    return tuple(centre)  

'''
*Function Name: calculate_Robot_State
*Input : img-> input frame captured by the camera
         aruco_list ->  dictionary containing aruco id as key and corner coordinates of the corresponding aruco
*Output: robot state -> dictionary containing (key,x coordinate of center, y coordinate of center, angle of the bot) for each aruco id in the list
*        displays angle of the bot on the screen
*Logic: uses angle_calculate to get the slope and the center is determined by ((x1+x2+x3+X4)/4,(y1+y2+y3+y4)/4)
*Example Call: robot_state = calculate_Robot_State(img,aruco_list)
'''

def calculate_Robot_State(img,aruco_list):  #gives the state of the bot (centre(x), centre(y), angle)
    robot_state = {}
    key_list = aruco_list.keys()
    font = cv2.FONT_HERSHEY_SIMPLEX

    for key in key_list:
        dict_entry = aruco_list[key]
        pt1 , pt2 = tuple(dict_entry[0]) , tuple(dict_entry[1])
        centre = dict_entry[0] + dict_entry[1] + dict_entry[2] + dict_entry[3]
        centre[:] = [int(x / 4) for x in centre]
        centre = tuple(centre)
        #print centre
        angle = angle_calculate(pt1, pt2)
        cv2.putText(img, str(angle), (int(centre[0] - 80), int(centre[1])), font, 1, (0,0,255), 2, cv2.LINE_AA)
        robot_state[key] = [key, int(centre[0]), int(centre[1]), angle]#HOWEVER IF YOU ARE SCALING IMAGE AND ALL...THEN BETTER INVERT X AND Y...COZ THEN ONLY THE RATIO BECOMES SAME
    #print (robot_state)
    return robot_state 

'''
*Function Name: mask_bot
*Input: highway -> the part of the image contained in the outer black ring (where the bot is allowed to travel)
*Output: highway -> returns image with the the aruco marker masked by a black square
*Logic: The coordinates of the corners of the aruco marker are detected and a black rectangle in drawn over the region on the input frame and returned. 
        This is to prevent white spots in the aruco being detected as false nodes. 
*Example Call: highway_without_bot = mask_bot(black_ring)
'''

def mask_bot(highway):
    aruco_list = detect_aruco(highway)
    center = get_aruco_center(aruco_list[BOT_ARUCO]) 
    x, y = center
    c1 = (x + 50, y + 50)
    c2 = (x + 50, y - 50)
    c3 = (x - 50, y - 50)
    c4 = (x - 50, y + 50)
    corners = np.int32([c1, c2, c3, c4])
    cv2.fillPoly(highway,[corners],(0,0,0))
    
    return highway

### Code to mark the extra arucos

'''
*Function Name: detect_other_arucos
*Input: img -> frame captured by camera
*Output: aruco_list -> list of corner coordinates of detected arucos belonging to 7x7 bit dictionary
*Logic: Using cv2.aruco library, arucos are detected
*Example Call: aruco_list = detect_other_arucos(img)
'''
def detect_other_arucos(img):  #returns the detected aruco list dictionary with id: corners
    aruco_list = {}
    dict_flag = cv2.aruco.DICT_7X7_250
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    aruco_dict = cv2.aruco.Dictionary_get(dict_flag)   #creating aruco_dict with 7x7 bits with max 250 ids..so ids ranges from 0-249
    parameters = cv2.aruco.DetectorParameters_create()  #refer opencv page for clarification
    corners, ids, _ = cv2.aruco.detectMarkers(gray, aruco_dict, parameters = parameters)
    gray = cv2.aruco.drawDetectedMarkers(gray, corners,ids)
    if len(corners):    
        for k in range(len(corners)):
            temp_1 = corners[k]
            temp_1 = temp_1[0]
            temp_2 = ids[k]
            temp_2 = temp_2[0]
            aruco_list[temp_2] = temp_1
        return aruco_list

'''
*Function Name: mark_other_arucos
*Input: img -> frame captured by camera
        aruco_list -> list of coordinates of arucos to be drawn 
*Output: img -> image with a green border drawn around the arucos
*Logic: Use of drawing functions to mark the aruco 
*Example Call: img = mark_other_arucos(img,aruco_list)
'''
def mark_other_arucos(img, aruco_list):    #function to mark the centre and display the id
    key_list = aruco_list.keys()
    font = cv2.FONT_HERSHEY_SIMPLEX
    for key in key_list:
        dict_entry = aruco_list[key]    #dict_entry is a numpy array with shape (4,2)
        centre = dict_entry[0] + dict_entry[1] + dict_entry[2] + dict_entry[3]#so being numpy array, addition is not list addition
        centre[:] = [int(x / 4) for x in centre]    #finding the centre
        #print centre
        orient_centre = centre + [0.0,5.0]
        #print orient_centre
        centre = tuple(centre)  
        # orient_centre = tuple((dict_entry[0]+dict_entry[1])/2)
        # cv2.circle(img,orient_centre,1,(0,0,255),8) #marking orient center 
        #cv2.line(img,centre,orient_centre,(255,0,0),4) #marking the centre of aruco
        dict_entry = np.int32(dict_entry)
        cv2.polylines(img,[dict_entry],1,(0,255,0),2)
        cv2.putText(img, str(key), (int(centre[0] + 20), int(centre[1])), font, 0.5, (255,0,0), 2, cv2.LINE_AA) # displaying the idno
    return img

'''
*Function Name: draw_other_arucos
*Input: img -> input image captured by camera
*Output: img -> image with arucos drawn on it 
*Logic: Use previously declared functions to detect and draw arucos 
*Example call: draw_other_arucos(img)
'''
def draw_other_arucos(img):
    #detection and drawing other arucos
    aruco_list = detect_other_arucos(img)
    img = mark_other_arucos(img,aruco_list)
    return img