#include <avr/io.h>

#define leftMotorComp	OCR0B
#define rightMotorComp	OCR0A

void motorsInit()
{
	// motor direction control pins set to output mode
	DDRB |= (1<<0)|(1<<3)|(1<<4)|(1<<5);
	// OC1B and OC1A Pins set to output mode
	DDRD |= (1<<5)|(1<<6);
	//Clear OC1A/OC1B on compare match when up-counting and set OC1A/OC1B
	//on compare match when downcounting (sets PWM to non-inverting mode)
	TCCR0A |= (1<<COM0A1) | (1<<COM0B1);
	// prescalar value 1
	TCCR0B |= (1<<CS00);
	//Fast PWM mode
	TCCR0A |= (1<<WGM01)|(1<<WGM00);
}


void motorSet(int leftMotorSpeed, int rightMotorSpeed, char direction) 
{
		leftMotorComp = leftMotorSpeed;
		rightMotorComp = rightMotorSpeed;
		if(direction== 'F')
		{
			PORTB |=(1<<3); 
			PORTB &=~(1<<0);
			PORTB |=(1<<5);
			PORTB &=~(1<<4);
		}
		else if(direction=='B')
		{
			PORTB |=(1<<0);
			PORTB &=~(1<<3);
			PORTB |=(1<<4);
			PORTB &=~(1<<5);
		}
		else
		{
			PORTB =0x00;		
		}	
}