#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "motorControl.h"
#include "follow_logic.h"
#include "Xbee.h"
#include "line_sensor.h"
#include "servo_strike.h"

#define buzzerPin 2

unsigned char data;

void beep_buzzer(int beep)
{	// 1 sec - twice on reaching city
	// 1 sec - After striking
	// 5 sec - After run completes
	//if(beep == 1)
	PORTD |= ~(1<<buzzerPin);  // active low
	if(beep == 0)
		PORTD |= (1<<buzzerPin);
}


ISR(USART_RX_vect)
{
	data = usart_read(); 
}

int main ()
{
	
	sei();
	//buzzer init
	DDRD|= (1<<buzzerPin);
	PORTD|= (1<<buzzerPin);
	
	motorsInit();
	ADCInit();
	usart_init();
	servo_init();
	
	uint16_t binaryArray[3];
	uint8_t readingBinary;
	char sensorChar[50],sensorCharMin[50],sensorCharMax[50];
	char temp;
	
	while(1){
	
		if (data == 's')  // stop to hit marker
		{
			motorSet(0, 0, 'c');
			UDR0 = 0x00;
			for (int i = 0; i < 2; i++)
			{
				PORTD &= ~(1<<buzzerPin);
				_delay_ms(8000);
				PORTD |= (1<<buzzerPin);
				_delay_ms(8000);
				
			}
			strike();
			reset_servo();
			while(data == 's')
			{
				_delay_ms(1000);
			}
			PORTD &= ~(1<<buzzerPin);
			_delay_ms(5000);
			PORTD |= (1<<buzzerPin);
						
		}
		else if(data == 'r')  // reset striking mechanism
		{
			reset_servo();
			while(data == 'r')
			{
				_delay_ms(1000);
			}
		}
		else if(data == 'l')  // long beep end of run
		{
			UDR0 = 0x00;
			motorSet(0, 0, 'c');
			// beep long buzzer
			PORTD &= ~(1<<buzzerPin);
			_delay_ms(40000);
			PORTD |= (1<<buzzerPin);
			break;	
		}			
		else if (data == 'c') // start moving
		{	
			UDR0 = 0x00;
			motorSpeed();

		}	
	}	
}


// ARCHIVE
//readingBinary= sensorsBinary();
/*for( int i=0;i<3;i++)
	{
		analogArray[i]= sensorsAnalog(i);
		if (analogArray[i] > 250) 
			{
				//sprintf(sensorChar,"%d",analogArray[i]);
		//for(int k= 0; sensorChar[k]!=0;k++)
			usart_send('0');
			}
		else usart_send('1');					
		usart_send('\t');
	}				
usart_send('\n');
}*/	

//usart_send('\n');

			