#include <avr/io.h>
#include <stdio.h>
#include <math.h>
#include "line_sensor.h"

#define input 0

#define clockwise 0
#define anticlockwise 1

#define Kp 0.1
#define Kd 0.1

//error weightage for each sensor//
#define x1 3500
#define x2 3500
#define x3 3500
uint16_t analogArray[numOfSensors];
int motorSpeedError, rightMotorSpeed, leftMotorSpeed;

int motorSpeed()
{
	int lastError;
	float P, D, error;
	
	int binary_tune[3];
	
		for( int i=0;i<3;i++)
		{
			analogArray[i]= sensorsAnalog(i);
			if (analogArray[i] > 250) 
				binary_tune[i]=0;
			else binary_tune[i] = 1;
		}
	
	//Readings of the 3 sensors are stored in an array sensorReading[3]
	//Desired readings of the sensor (no error condition) in setPoint[3]
	unsigned int sensorPIDReading[numOfSensors], setpointReading[numOfSensors], errorReading[numOfSensors];
	
	ADCInit();
		
		if (binary_tune[1] == 0 && binary_tune[2] == 1 && binary_tune[0] == 0  ) motorSet(160, 175, 'F');
		else if (binary_tune[1] == 1 && binary_tune[2] == 0 && binary_tune[0] == 0 ) motorSet(170, 140, 'F');
		else if (binary_tune[1] == 0 && binary_tune[2] == 0 && binary_tune[0] == 1 ) motorSet(145, 175, 'F');
		else if (binary_tune[1] == 0 && binary_tune[2] == 0 && binary_tune[0] == 0 ) motorSet(140, 175,'F');
		else motorSet(155, 175, 'F');
}
	