#define OCR1_2ms 3999
#define OCR1_1ms 1800

float duty_time;

void servo_begin()
{
	/*Set pre-scaler of 8 with Fast PWM (Mode 14 i.e TOP value as ICR1)  non-inverting mode */
	DDRB |= 1 << PINB1;
	TCCR1A |= (1 << WGM11) | (1 << COM1A1);
	TCCR1B |= (1 << WGM12) | (1 << WGM13) | (1 << CS11);
	ICR1 = 39999; // Set pwm period as 20ms
}

// Write the servo's angle
void servo_write(float angle)
{
	OCR1A = (OCR1_1ms*0.05 + (angle*OCR1_1ms/180)); // Map angle to OCR1 value
}

void servo_init()
{
	servo_begin();
	servo_write(310);
	_delay_ms(10000);
}

void reset_servo()
{
	servo_write(200);
	_delay_ms(10000);
	
}
void strike()
{
	servo_write(109);
	_delay_ms(10000);
}
