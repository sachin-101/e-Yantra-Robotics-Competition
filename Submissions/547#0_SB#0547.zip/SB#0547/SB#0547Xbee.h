// Xbee communication//

char usart_read() {
while( !(UCSR0A & (1<<RXC0))) { }
return UDR0;
}

