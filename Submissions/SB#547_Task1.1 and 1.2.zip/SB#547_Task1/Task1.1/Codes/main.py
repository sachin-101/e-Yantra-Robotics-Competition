###############################################################################
## Author: Team Supply Bot
## Edition: eYRC 2019-20
## Instructions: Do Not modify the basic skeletal structure of given APIs!!!
###############################################################################
######################
## Essential libraries
######################
import cv2
import numpy as np
import os
from math import sqrt,pi,asin
import csv


########################################################################
## using os to generalise Input-Output
########################################################################
codes_folder_path = os.path.abspath('C:/Users/Kirthika/Desktop/task1#sb/Task1.1')
images_folder_path = os.path.abspath(os.path.join('C:/Users/Kirthika/Desktop/task1#sb/Task1.1', 'Images'))
generated_folder_path = os.path.abspath(os.path.join('C:/Users/Kirthika/Desktop/task1#sb/Task1.1', 'Generated'))


############################################
## Build your algorithm in this function
## ip_image: is the array of the input image
## imshow helps you view that you have loaded
## the corresponding image
############################################
def process(ip_image):
    ###########################
    ## Your Code goes here
    angle = 0.00
    upper_red = np.array([7,7,255])         #define the range of shades of red
    lower_red = np.array([0,0,199])
    mask_red = cv2.inRange(ip_image,lower_red,upper_red)    #extracts the red part of the image
    mask_red = cv2.GaussianBlur(mask_red,(3,3),cv2.BORDER_DEFAULT)

    upper_green = np.array([7,255,7])       #define the range of shades of green
    lower_green = np.array([0,199,0])       #extracts the green part of the image 
    mask_green = cv2.inRange(ip_image,lower_green,upper_green)
    mask_green = cv2.GaussianBlur(mask_green,(3,3),cv2.BORDER_DEFAULT)

    mask_origin = cv2.cvtColor(ip_image,cv2.COLOR_BGR2GRAY)     #extracts the white dot at the center
    ret,mask_origin = cv2.threshold(mask_origin,250,255,cv2.THRESH_BINARY)
    mask_origin = cv2.GaussianBlur(mask_origin,(3,3),cv2.BORDER_DEFAULT)

    cnt_red, hierarchy = cv2.findContours(mask_red,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    (x1,y1),rad_red = cv2.minEnclosingCircle(cnt_red[0])         #coordinates of the center of the red dot

    cnt_green, hierarchy = cv2.findContours(mask_green,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    (x2,y2),rad_green = cv2.minEnclosingCircle(cnt_green[0])        #coordinates of center of green dot
    
    cnt_origin, hierarchy = cv2.findContours(mask_origin,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    (x0,y0),rad_origin = cv2.minEnclosingCircle(cnt_origin[2])      #coordinates of center of origin

    vx = x2-x1                  #distance from red dot to green dot
    vy = y2-y1
    vrx1 = x1-x0                 #distance from red dot to origin (radius)
    vry1 = y1-y0
    vrx2 = x2 - x0
    vry2 = y2 - y0

#Calculating Angle A
    l = sqrt((vx*vx)+(vy*vy))       #using the formula sin(A/2) = l/2r where A is the angle between the lines
    r1 = sqrt((vrx1*vrx1)+(vry1*vry1))
    r2 = sqrt((vrx2*vrx2)+(vry2*vry2))
    r = (r1+r2)/2
    theta = l/(2*r)
    angle = (2*asin(theta)*180)/pi
    A = round(angle,2)
    print(A)
    
    cv2.imshow("window", ip_image)
    cv2.waitKey(0);
    return A
    
    
####################################################################
## The main program which provides read in input of one image at a
## time to process function in which you will code your generalized
## output computing code
## Do not modify this code!!!
####################################################################
def main():
    ################################################################
    ## variable declarations
    ################################################################
    i = 1
    line = []
    ## Reading 1 image at a time from the Images folder
    for image_name in os.listdir(images_folder_path):
        ## verifying name of image
        print(image_name)
        ## reading in image 
        ip_image = cv2.imread(images_folder_path+"/"+image_name)
        ## verifying image has content
        print(ip_image.shape)
        ## passing read in image to process function
        A = process(ip_image)
        ## saving the output in  a list variable
        line.append([str(i), image_name , str(A)])
        ## incrementing counter variable
        i+=1
    ## verifying all data
    print(line)
    ## writing to angles.csv in Generated folder without spaces
    with open(generated_folder_path+"/"+'angles.csv', 'w', newline='') as writeFile:
        writer = csv.writer(writeFile)
        writer.writerows(line)
    ## closing csv file    
    writeFile.close()


############################################################################################
## main function
############################################################################################
if __name__ == '__main__':
    main()
