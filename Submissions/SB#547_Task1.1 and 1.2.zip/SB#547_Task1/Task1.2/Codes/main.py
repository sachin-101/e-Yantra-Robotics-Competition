###############################################################################
## Author: Team Supply Bot
## Edition: eYRC 2019-20
## Instructions: Do Not modify the basic skeletal structure of given APIs!!!
###############################################################################


######################
## Essential libraries
######################
import cv2
import numpy as np
import os
import math
import csv

 


########################################################################
## using os to generalise Input-Output
########################################################################
codes_folder_path = os.path.abspath('.')
images_folder_path = os.path.abspath(os.path.join('..', 'Images'))
generated_folder_path = os.path.abspath(os.path.join('..', 'Generated'))




############################################
## Build your algorithm in this function
## ip_image: is the array of the input image
## imshow helps you view that you have loaded
## the corresponding image
############################################
def process(ip_image):
    ###########################
    ## Your Code goes here
    black_thresh, white_thresh = 35, 220
    im_gray = cv2.cvtColor(ip_image, cv2.COLOR_BGR2GRAY)
    
    ret, black = cv2.threshold(im_gray, black_thresh, 255, 0)   # extracts black region from image
    ret, white = cv2.threshold(im_gray, white_thresh, 255, 0)   # extracts white region from image
    
    kernel = np.ones((2, 2), np.uint8)
    eroded = cv2.erode(black, kernel)    # to remove noise

    contours, _ = cv2.findContours(eroded, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)  # Search for contours in the image
    
    inner_circle = np.zeros_like(im_gray)
    cv2.drawContours(inner_circle, contours, 1, 255, -1)   # draw the inner circle
    y, x = int(inner_circle.shape[0]/2), int(inner_circle.shape[1]/2)
    max_radius = int(inner_circle.shape[1]/2)
    
    # logic to find the inner and radius of the inner black circle
    in_radius, out_radius = -1, -1
    for r in range(max_radius):
        right = inner_circle[y, x+r] == 255
        left = inner_circle[y, x-r] == 255
        up = inner_circle[y-r, x] == 255
        down = inner_circle[y+r , x] == 255
        if right or up or left or down:
            if in_radius == -1:
                in_radius = r
            out_radius = r
    
    # draw the mask, basically two circles with radius in_radius and out_radius 
    mask = np.zeros_like(white)
    cv2.circle(mask, (y, x), in_radius + 1, 255)
    cv2.circle(mask, (y, x), out_radius - 1, 255)

    # Highlight the sector by taking bitwise or
    circle_with_sector = cv2.bitwise_or(mask, inner_circle)
    countors2, _ = cv2.findContours(circle_with_sector, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    ## placeholder image
    sector_image = np.ones(ip_image.shape[:2],np.uint8)*255
    ## check value is white or not
    print(sector_image[0,0])
    cv2.drawContours(sector_image, countors2, 1, 0, -1)  # Add sector countor
    ###########################
    cv2.imshow("window", sector_image)
    cv2.waitKey(0);
    return sector_image


    
####################################################################
## The main program which provides read in input of one image at a
## time to process function in which you will code your generalized
## output computing code
## Do not modify this code!!!
####################################################################
def main():
    ################################################################
    ## variable declarations
    ################################################################
    i = 1
    ## Reading 1 image at a time from the Images folder
    for image_name in os.listdir(images_folder_path):
        ## verifying name of image
        print(image_name)
        ## reading in image 
        ip_image = cv2.imread(images_folder_path+"/"+image_name)
        ## verifying image has content
        print(ip_image.shape)
        ## passing read in image to process function
        sector_image = process(ip_image)
        ## saving the output in  an image of said name in the Generated folder
        cv2.imwrite(generated_folder_path+"/"+"image_"+str(i)+"_fill_in.png", sector_image)
        i+=1


    

############################################################################################
## main function
############################################################################################
if __name__ == '__main__':
    main()
